import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [ CommonModule, RouterModule ],
  templateUrl: './navbar.html',
})
export class NavbarComponent {
  @Input() menuItems: { label: string, path?: string, action?: () => void }[] = [
    { label: 'Home', action: () => this.scrollToTop() },
    { label: 'AboutUs', action: () => this.scrollToCards() },
    { label: 'Login', action: () => this.goToLogin() }
  ];
  @Output() brandClick = new EventEmitter<void>();

  constructor(private authService: AuthService, private router: Router) {}

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }

  onBrandClick(event: Event) {
    event.preventDefault();
    this.brandClick.emit();
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  scrollToCards() {
    const cardsSection = document.getElementById('cards-section');
    if (cardsSection) {
      cardsSection.scrollIntoView({ behavior: 'smooth' });
    }
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }

  goToLoginFromExplore() {
    this.router.navigate(['/login']);
  }
}
