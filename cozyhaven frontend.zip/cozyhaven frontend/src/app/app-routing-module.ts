import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login';
import { AdminComponent } from './admin/admin';
import { UserComponent } from './user/user';
import { OwnerComponent } from './owner/owner';
import { AuthGuard } from './auth.guard';
import { BookingComponent } from './booking/booking';

const routes: Routes = [
  { path: '', loadComponent: () => import('./home/home').then(m => m.HomeComponent) },
  { path: 'login', component: LoginComponent },
  { path: 'admin', component: AdminComponent, canActivate: [AuthGuard], data: { role: 'ADMIN' } },
  { path: 'user', component: UserComponent, canActivate: [AuthGuard], data: { role: 'GUEST' } },
  { path: 'user/booking/:hotelId', component: BookingComponent, canActivate: [AuthGuard], data: { role: 'GUEST' } },
  {
    path: 'user/profile',
    loadComponent: () => import('./profile/profile').then(m => m.ProfileComponent),
    canActivate: [AuthGuard],
    data: { role: 'GUEST' }
  },
  { path: 'owner', component: OwnerComponent, canActivate: [AuthGuard], data: { role: 'OWNER' } },
  { path: '**', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
