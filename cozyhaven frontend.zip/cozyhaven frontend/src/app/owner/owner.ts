import { Component, OnInit } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NgbCarouselModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { SafePipe } from '../safe.pipe';

interface Hotel {
  name: string;
  location: string;
  description: string;
  amenities: string;
  image: string;
}

@Component({
  selector: 'app-owner',
  standalone: true,
  imports: [ NavbarComponent, CommonModule, FormsModule, NgbCarouselModule, SafePipe ],
  templateUrl: './owner.html',
  styleUrls: ['./owner.css']
})
export class OwnerComponent implements OnInit {
  ownerMenuItems = [
    { label: 'Add Hotel', action: () => this.showAddHotelForm() },
    { label: 'Add Room', action: () => this.showAddRoomForm() },
    { label: 'Delete Hotel', action: () => this.showDeleteHotelForm() },
    { label: 'View Hotels', action: () => this.viewHotels() },
  ];

  showAddHotel = false;
  showAddRoom = false;
  showDeleteHotel = false;
  showHotels = false;
  hotels: any[] = [];
  hotelIdToDelete: number | null = null;
  hotelNameToDelete: string = '';
  deleteBy: 'id' | 'name' = 'id';
  hotelInfoToDelete: any = null;
  selectedFile: File | null = null;

  hotel: Hotel = {
    name: '',
    location: '',
    description: '',
    amenities: '',
    image: '',
  };

  room = {
    roomSize: '',
    bedType: '',
    maxOccupancy: 0,
    baseFare: 0,
    ac: false,
    hotelId: 0,
  };

  ownerName: string = '';
  hotelNameForRoom: string = '';
  hotelIdError: string = '';

  hotelAddLoading = false;
  hotelAddSuccess = false;
  roomAddLoading = false;
  roomAddSuccess = false;

  constructor(private http: HttpClient, private authService: AuthService, private router: Router) {}

  ngOnInit() {
    const email = this.authService.getEmail();
    if (email) {
      this.authService.getUsers().subscribe(users => {
        const owner = users.find((user: any) => user.email === email);
        if (owner) {
          this.ownerName = owner.name;
        }
      });
    }
  }

  showAddHotelForm() {
    this.showAddHotel = true;
    this.showAddRoom = false;
    this.showDeleteHotel = false;
    this.showHotels = false;
  }

  showAddRoomForm() {
    this.showAddHotel = false;
    this.showAddRoom = true;
    this.showDeleteHotel = false;
    this.showHotels = false;
  }

  showDeleteHotelForm() {
    this.showAddHotel = false;
    this.showAddRoom = false;
    this.showDeleteHotel = true;
    this.showHotels = false;
  }

  showWelcome() {
    this.showAddHotel = false;
    this.showAddRoom = false;
    this.showDeleteHotel = false;
    this.showHotels = false;
  }

  addHotel() {
    if (!this.selectedFile) {
      alert('Please select an image for the hotel.');
      return;
    }
    this.hotelAddLoading = true;
    this.hotelAddSuccess = false;
    const formData = new FormData();
    formData.append('name', this.hotel.name);
    formData.append('location', this.hotel.location);
    formData.append('description', this.hotel.description);
    formData.append('amenities', this.hotel.amenities);
    formData.append('image', this.selectedFile, this.selectedFile.name);
    this.http
      .post('http://localhost:8080/api/hotels', formData)
      .subscribe(() => {
        this.hotelAddLoading = false;
        this.hotelAddSuccess = true;
        setTimeout(() => {
          this.hotelAddSuccess = false;
          this.showAddHotel = false;
        }, 1500);
        this.hotel = {
          name: '',
          location: '',
          description: '',
          amenities: '',
          image: '',
        };
        this.selectedFile = null;
      }, () => {
        this.hotelAddLoading = false;
      });
  }

  addRoom() {
    this.roomAddLoading = true;
    this.roomAddSuccess = false;
    this.http.post('http://localhost:8080/api/rooms', this.room).subscribe(() => {
      this.roomAddLoading = false;
      this.roomAddSuccess = true;
      setTimeout(() => {
        this.roomAddSuccess = false;
        this.showAddRoom = false;
      }, 1500);
      this.room = {
        roomSize: '',
        bedType: '',
        maxOccupancy: 0,
        baseFare: 0,
        ac: false,
        hotelId: 0,
      };
    }, () => {
      this.roomAddLoading = false;
    });
  }

  deleteHotel() {
    if (this.hotelIdToDelete) {
      this.http.delete(`http://localhost:8080/api/hotels/${this.hotelIdToDelete}`).subscribe(() => {
        alert('Hotel deleted successfully!');
        this.hotelIdToDelete = null;
        this.showDeleteHotel = false;
      }, () => {
        alert('Failed to delete hotel.');
      });
    }
  }

  deleteHotelByName() {
    if (!this.hotelInfoToDelete || !this.hotelInfoToDelete.id) {
      alert('No hotel selected for deletion.');
      return;
    }
    const hotelId = this.hotelInfoToDelete.id;
    this.http.delete(`http://localhost:8080/api/hotels/${hotelId}`).subscribe(() => {
      alert('Hotel deleted successfully!');
      this.hotelNameToDelete = '';
      this.hotelInfoToDelete = null;
      this.showDeleteHotel = false;
    }, () => {
      alert('Failed to delete hotel.');
    });
  }

  fetchHotelInfoForDelete() {
    const name = this.hotelNameToDelete ? this.hotelNameToDelete.trim() : '';
    if (!name) {
      alert('Please enter a hotel name.');
      return;
    }
    const encodedName = encodeURIComponent(name);
    this.http.get<any>(`http://localhost:8080/api/hotels/searchByName?name=${encodedName}`)
      .subscribe(
        (hotel) => {
          let hotelObj = null;
          if (hotel && hotel.id) {
            hotelObj = hotel;
          } else if (Array.isArray(hotel) && hotel.length > 0 && hotel[0].id) {
            hotelObj = hotel[0];
          }
          if (hotelObj) {
            this.hotelInfoToDelete = hotelObj;
          } else {
            this.hotelInfoToDelete = null;
            alert('Hotel with that name does not exist.');
          }
        },
        () => {
          this.hotelInfoToDelete = null;
          alert('Hotel with that name does not exist.');
        }
      );
  }

  onFileSelected(event: any) {
    if (event.target.files && event.target.files.length) {
      this.selectedFile = event.target.files[0];
    }
  }

  checkHotelByName() {
    const name = this.hotelNameForRoom ? this.hotelNameForRoom.trim() : '';
    if (!name) {
      this.hotelIdError = '';
      this.room.hotelId = 0;
      return;
    }
    const encodedName = encodeURIComponent(name);
    this.http.get<any>(`http://localhost:8080/api/hotels/searchByName?name=${encodedName}`)
      .subscribe(
        (hotel) => {
          if (hotel && hotel.id) {
            this.room.hotelId = hotel.id;
            this.hotelIdError = '';
          } else if (Array.isArray(hotel) && hotel.length > 0 && hotel[0].id) {
            this.room.hotelId = hotel[0].id;
            this.hotelIdError = '';
          } else {
            this.room.hotelId = 0;
            this.hotelIdError = "Hotel with that name doesn't exist.";
          }
        },
        () => {
          this.room.hotelId = 0;
          this.hotelIdError = "Hotel with that name doesn't exist.";
        }
      );
  }

  viewHotels() {
    this.http.get<any[]>('http://localhost:8080/api/hotels').subscribe((data) => {
      this.hotels = data;
      this.showHotels = true;
      this.showAddHotel = false;
      this.showAddRoom = false;
      this.showDeleteHotel = false;
    });
  }
}
