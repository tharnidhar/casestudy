import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NumbersOnlyDirective } from '../numbers-only.directive';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { AuthService } from '../auth.service';
import { NavbarComponent } from '../navbar/navbar';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ FormsModule, CommonModule, HttpClientModule, NumbersOnlyDirective, NavbarComponent ],
  templateUrl: './login.html',
  styleUrls: ['./login.css']
})
export class LoginComponent {
  email = '';
  password = '';
  role = 'GUEST';
  isRegistering = false;
  emailExists = false;
  showPassword = false;
  registerData = {
    name: '',
    email: '',
    password: '',
    gender: 'male',
    contactNumber: '',
    address: '',
    role: 'GUEST'
  };

  loginMenuItems = [
    { label: 'Home', action: () => this.goHome() },
    { label: 'AboutUs', action: () => this.scrollToCards() },
    { label: 'Login', action: () => {} }
  ];

  constructor(private router: Router, private http: HttpClient, private authService: AuthService) {}

  login() {
    const credentials = { email: this.email, password: this.password };
    this.authService.login(credentials).subscribe(response => {
      localStorage.setItem('token', response.token);
      this.authService.getUsers().subscribe(users => {
        const user = users.find(u => u.email === this.email);
        if (user && user.role === this.role) {
          switch (this.role) {
            case 'GUEST':
            this.router.navigate(['/user']);
            break;
            case 'OWNER':
              this.router.navigate(['/owner']);
              break;
            case 'ADMIN':
              this.router.navigate(['/admin']);
              break;
          }
        } else {
          alert('Invalid role for this user.');
        }
      });
    }, error => {
      console.error('Login failed', error);
      alert('Login failed');
    });
  }

  togglePasswordVisibility() {
    this.showPassword = !this.showPassword;
  }

  toggleRegister() {
    this.isRegistering = !this.isRegistering;
    if (!this.isRegistering) {
      this.clearRegisterData();
    }
  }

  clearRegisterData() {
    this.registerData = {
      name: '',
      email: '',
      password: '',
      gender: 'male',
      contactNumber: '',
      address: '',
      role: 'GUEST'
    };
    this.emailExists = false;
  }

  checkEmailExists() {
    this.authService.getUsers().subscribe(users => {
      this.emailExists = users.some(user => user.email === this.registerData.email);
    });
  }

  register() {
    const mobileNumberPattern = /^[0-9]{10}$/;
    if (!mobileNumberPattern.test(this.registerData.contactNumber)) {
      alert('Please enter a valid 10-digit mobile number.');
      return;
    }

    this.authService.register(this.registerData)
      .subscribe(response => {
        alert('Registered successfully');
        this.isRegistering = false;
        this.clearRegisterData();
      }, error => {
        console.error('Registration failed', error);
        alert('Registration failed');
      });
  }

  goHome() {
    this.router.navigate(['/']);
  }

  scrollToCards() {
    this.router.navigate(['/'], { fragment: 'cards-section' });
    setTimeout(() => {
      const cardsSection = document.getElementById('cards-section');
      if (cardsSection) {
        cardsSection.scrollIntoView({ behavior: 'smooth' });
      }
    }, 300);
  }
}