import '@angular/localize/init';
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app';
import { importProvidersFrom } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { AppRoutingModule } from './app/app-routing-module';

bootstrapApplication(AppComponent, {
  providers: [
    importProvidersFrom(FormsModule, AppRoutingModule),
    provideHttpClient(withInterceptorsFromDi()),
  ],
});