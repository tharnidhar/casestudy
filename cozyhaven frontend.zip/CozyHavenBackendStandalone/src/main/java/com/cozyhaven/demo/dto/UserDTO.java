package com.cozyhaven.demo.dto;


import com.cozyhaven.demo.entity.Role;
import lombok.Data;

@Data
public class UserDTO {
    private Long id;
    private String name;
    private String email;
    private String password;
    private String gender;
    private String contactNumber;
    private String address;
    private Role role;
}
