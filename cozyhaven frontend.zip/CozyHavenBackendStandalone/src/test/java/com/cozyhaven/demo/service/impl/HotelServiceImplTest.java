
package com.cozyhaven.demo.service.impl;

import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.repository.HotelRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class HotelServiceImplTest {

    @InjectMocks
    private HotelServiceImpl hotelService;

    @Mock
    private HotelRepository hotelRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddHotel() {
        Hotel hotel = new Hotel();
        when(hotelRepository.save(any(Hotel.class))).thenReturn(hotel);

        Hotel addedHotel = hotelService.addHotel(hotel);

        assertNotNull(addedHotel);
        verify(hotelRepository, times(1)).save(hotel);
    }

    @Test
    void testGetHotelById() {
        Hotel hotel = new Hotel();
        hotel.setId(1L);
        when(hotelRepository.findById(1L)).thenReturn(Optional.of(hotel));

        Hotel foundHotel = hotelService.getHotelById(1L);

        assertNotNull(foundHotel);
        assertEquals(1L, foundHotel.getId());
        verify(hotelRepository, times(1)).findById(1L);
    }

    @Test
    void testGetAllHotels() {
        Hotel hotel = new Hotel();
        when(hotelRepository.findAll()).thenReturn(Collections.singletonList(hotel));

        List<Hotel> hotels = hotelService.getAllHotels();

        assertNotNull(hotels);
        assertEquals(1, hotels.size());
        verify(hotelRepository, times(1)).findAll();
    }

    @Test
    void testSearchHotelsByLocation() {
        String location = "Test Location";
        Hotel hotel = new Hotel();
        hotel.setLocation(location);
        when(hotelRepository.findByLocationContainingIgnoreCase(location)).thenReturn(Collections.singletonList(hotel));

        List<Hotel> hotels = hotelService.searchHotelsByLocation(location);

        assertNotNull(hotels);
        assertEquals(1, hotels.size());
        assertEquals(location, hotels.get(0).getLocation());
        verify(hotelRepository, times(1)).findByLocationContainingIgnoreCase(location);
    }

    @Test
    void testDeleteHotel() {
        doNothing().when(hotelRepository).deleteById(1L);

        hotelService.deleteHotel(1L);

        verify(hotelRepository, times(1)).deleteById(1L);
    }
}
