package com.cozyhaven.demo.service;


import com.cozyhaven.demo.entity.Booking;
import com.cozyhaven.demo.entity.User;

import java.util.List;

public interface BookingService {
    Booking createBooking(Booking booking);
    Booking getBookingById(Long id);
    List<Booking> getBookingsByUser(User user);
    void cancelBooking(Long id);
}

