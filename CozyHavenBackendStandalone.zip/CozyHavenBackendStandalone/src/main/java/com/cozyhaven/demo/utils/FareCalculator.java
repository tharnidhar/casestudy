package com.cozyhaven.demo.utils;


public class FareCalculator {

    public static double calculateTotalFare(
        double baseFare,
        String bedType,
        int numAdults,
        int numChildren
    ) {
        int maxOccupancy = switch (bedType.toUpperCase()) {
            case "SINGLE" -> 2;
            case "DOUBLE" -> 4;
            case "KING" -> 6;
            default -> 2;
        };

        int totalGuests = numAdults + numChildren;
        int overLimit = totalGuests - maxOccupancy;

        if (overLimit <= 0) return baseFare;

        double extraFare = 0;
        for (int i = 1; i <= overLimit; i++) {
            // Assume first extra person is adult if total adults > maxOccupancy / 2
            if (i <= numAdults) {
                extraFare += baseFare * 0.40;
            } else {
                extraFare += baseFare * 0.20;
            }
        }

        return baseFare + extraFare;
    }
}
