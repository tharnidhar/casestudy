package com.cozyhaven.demo.controller;


import com.cozyhaven.demo.dto.UserDTO;
import com.cozyhaven.demo.entity.User;
import com.cozyhaven.demo.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    
    private User toEntity(UserDTO dto) {
        return User.builder()
                .id(dto.getId())
                .name(dto.getName())
                .email(dto.getEmail())
                .password(dto.getPassword())
                .gender(dto.getGender())
                .contactNumber(dto.getContactNumber())
                .address(dto.getAddress())
                .role(dto.getRole())
                .build();
    }
    


    @PostMapping("/register")
    public UserDTO registerUser(@RequestBody UserDTO dto) {
        User user = toEntity(dto);
        User savedUser = userService.registerUser(user);
        return toDTO(savedUser);
    }


    @GetMapping
    public List<UserDTO> getAllUsers() {
        return userService.getAllUsers()
                .stream().map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public UserDTO getUser(@PathVariable Long id) {
        return userService.getUserById(id)
                .map(this::toDTO).orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    private UserDTO toDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setName(user.getName());
        dto.setEmail(user.getEmail());
        dto.setPassword(user.getPassword());
        dto.setGender(user.getGender());
        dto.setContactNumber(user.getContactNumber());
        dto.setAddress(user.getAddress());
        dto.setRole(user.getRole());
        return dto;
    }
}
