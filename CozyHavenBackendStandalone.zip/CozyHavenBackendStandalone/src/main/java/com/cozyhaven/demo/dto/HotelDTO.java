package com.cozyhaven.demo.dto;


import lombok.Data;

@Data
public class HotelDTO {
    private Long id;
    private String name;
    private String location;
    private String description;
    private String amenities; // Could also be List<String> with custom mapping
    private String image;
}
