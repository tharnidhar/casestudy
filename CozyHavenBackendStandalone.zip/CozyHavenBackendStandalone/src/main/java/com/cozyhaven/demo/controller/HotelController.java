package com.cozyhaven.demo.controller;


import com.cozyhaven.demo.dto.CreateHotelRequest;
import com.cozyhaven.demo.dto.HotelDTO;
import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.service.HotelService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/hotels")
@RequiredArgsConstructor
public class HotelController {

    private final HotelService hotelService;

    @PostMapping
    public HotelDTO addHotel(@RequestParam("name") String name,
                             @RequestParam("location") String location,
                             @RequestParam("description") String description,
                             @RequestParam("amenities") String amenities,
                             @RequestParam(value = "image", required = false) MultipartFile image) throws IOException {
        Hotel hotel = Hotel.builder()
                .name(name)
                .location(location)
                .description(description)
                .amenities(amenities)
                .build();
        if (image != null && !image.isEmpty()) {
            hotel.setImage(image.getBytes());
        }

        return toDTO(hotelService.addHotel(hotel));
    }

    @GetMapping
    public List<HotelDTO> getAllHotels() {
        return hotelService.getAllHotels().stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/search")
    public List<HotelDTO> searchHotels(@RequestParam String location) {
        return hotelService.searchHotelsByLocation(location).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/searchByName")
    public List<HotelDTO> searchHotelsByName(@RequestParam String name) {
        return hotelService.searchHotelsByName(name).stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public HotelDTO getHotel(@PathVariable Long id) {
        return toDTO(hotelService.getHotelById(id));
    }

    @DeleteMapping("/{id}")
    public void deleteHotel(@PathVariable Long id) {
        hotelService.deleteHotel(id);
    }

    private HotelDTO toDTO(Hotel h) {
        HotelDTO dto = new HotelDTO();
        dto.setId(h.getId());
        dto.setName(h.getName());
        dto.setLocation(h.getLocation());
        dto.setDescription(h.getDescription());
        dto.setAmenities(h.getAmenities());
        if (h.getImage() != null) {
            dto.setImage(Base64.getEncoder().encodeToString(h.getImage()));
        }
        return dto;
    }
}
