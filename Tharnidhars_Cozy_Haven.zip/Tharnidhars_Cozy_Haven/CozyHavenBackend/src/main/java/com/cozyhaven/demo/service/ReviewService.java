package com.cozyhaven.demo.service;


import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Review;

import java.util.List;

public interface ReviewService {
    Review addReview(Review review);
    List<Review> getReviewsByHotel(Hotel hotel);
}
