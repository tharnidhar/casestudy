package com.cozyhaven.demo.dto;


import lombok.Data;

@Data
public class ReviewDTO {
    private Long id;
    private Long userId;
    private Long hotelId;
    private Integer rating;
    private String comment;
}
