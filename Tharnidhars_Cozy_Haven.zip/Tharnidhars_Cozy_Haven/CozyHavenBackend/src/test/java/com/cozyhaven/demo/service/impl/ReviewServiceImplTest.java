
package com.cozyhaven.demo.service.impl;

import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Review;
import com.cozyhaven.demo.repository.ReviewRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ReviewServiceImplTest {

    @InjectMocks
    private ReviewServiceImpl reviewService;

    @Mock
    private ReviewRepository reviewRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddReview() {
        Review review = new Review();
        when(reviewRepository.save(any(Review.class))).thenReturn(review);

        Review addedReview = reviewService.addReview(review);

        assertNotNull(addedReview);
        verify(reviewRepository, times(1)).save(review);
    }

    @Test
    void testGetReviewsByHotel() {
        Hotel hotel = new Hotel();
        hotel.setId(1L);
        Review review = new Review();
        review.setHotel(hotel);
        when(reviewRepository.findByHotel(hotel)).thenReturn(Collections.singletonList(review));

        List<Review> reviews = reviewService.getReviewsByHotel(hotel);

        assertNotNull(reviews);
        assertEquals(1, reviews.size());
        assertEquals(hotel, reviews.get(0).getHotel());
        verify(reviewRepository, times(1)).findByHotel(hotel);
    }
}
