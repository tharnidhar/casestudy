
package com.cozyhaven.demo.service.impl;

import com.cozyhaven.demo.entity.Hotel;
import com.cozyhaven.demo.entity.Room;
import com.cozyhaven.demo.repository.RoomRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class RoomServiceImplTest {

    @InjectMocks
    private RoomServiceImpl roomService;

    @Mock
    private RoomRepository roomRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testAddRoom() {
        Room room = new Room();
        when(roomRepository.save(any(Room.class))).thenReturn(room);

        Room addedRoom = roomService.addRoom(room);

        assertNotNull(addedRoom);
        verify(roomRepository, times(1)).save(room);
    }

    @Test
    void testGetRoomById() {
        Room room = new Room();
        room.setId(1L);
        when(roomRepository.findById(1L)).thenReturn(Optional.of(room));

        Room foundRoom = roomService.getRoomById(1L);

        assertNotNull(foundRoom);
        assertEquals(1L, foundRoom.getId());
        verify(roomRepository, times(1)).findById(1L);
    }

    @Test
    void testGetRoomsByHotel() {
        Hotel hotel = new Hotel();
        hotel.setId(1L);
        Room room = new Room();
        room.setHotel(hotel);
        when(roomRepository.findByHotel(hotel)).thenReturn(Collections.singletonList(room));

        List<Room> rooms = roomService.getRoomsByHotel(hotel);

        assertNotNull(rooms);
        assertEquals(1, rooms.size());
        assertEquals(hotel, rooms.get(0).getHotel());
        verify(roomRepository, times(1)).findByHotel(hotel);
    }

    @Test
    void testDeleteRoom() {
        doNothing().when(roomRepository).deleteById(1L);

        roomService.deleteRoom(1L);

        verify(roomRepository, times(1)).deleteById(1L);
    }
}
