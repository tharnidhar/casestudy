
package com.cozyhaven.demo.service.impl;

import com.cozyhaven.demo.entity.Booking;
import com.cozyhaven.demo.entity.User;
import com.cozyhaven.demo.repository.BookingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class BookingServiceImplTest {

    @InjectMocks
    private BookingServiceImpl bookingService;

    @Mock
    private BookingRepository bookingRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testCreateBooking() {
        Booking booking = new Booking();
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        Booking createdBooking = bookingService.createBooking(booking);

        assertNotNull(createdBooking);
        assertEquals("BOOKED", createdBooking.getStatus());
        verify(bookingRepository, times(1)).save(booking);
    }

    @Test
    void testGetBookingById() {
        Booking booking = new Booking();
        booking.setId(1L);
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));

        Booking foundBooking = bookingService.getBookingById(1L);

        assertNotNull(foundBooking);
        assertEquals(1L, foundBooking.getId());
        verify(bookingRepository, times(1)).findById(1L);
    }

    @Test
    void testGetBookingsByUser() {
        User user = new User();
        user.setId(1L);
        Booking booking = new Booking();
        booking.setUser(user);
        when(bookingRepository.findByUser(user)).thenReturn(Collections.singletonList(booking));

        List<Booking> bookings = bookingService.getBookingsByUser(user);

        assertNotNull(bookings);
        assertEquals(1, bookings.size());
        assertEquals(user, bookings.get(0).getUser());
        verify(bookingRepository, times(1)).findByUser(user);
    }

    @Test
    void testCancelBooking() {
        Booking booking = new Booking();
        booking.setId(1L);
        booking.setStatus("BOOKED");
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(booking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(booking);

        bookingService.cancelBooking(1L);

        assertEquals("CANCELLED", booking.getStatus());
        verify(bookingRepository, times(1)).findById(1L);
        verify(bookingRepository, times(1)).save(booking);
    }
}
