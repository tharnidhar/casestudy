import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { NavbarComponent } from '../navbar/navbar';
import { HttpClient } from '@angular/common/http';
import { NgbCarouselModule } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';
import { SafePipe } from '../safe.pipe';

interface User {
  id: number;
  name: string;
  email: string;
  gender: string;
  contactNumber: string;
  address: string;
  role: string;
}

interface Hotel {
  id: number;
  name: string;
  location: string;
  description: string;
  amenities: string;
  image: string;
}

interface Room {
  id: number;
  roomSize: string;
  bedType: string;
  maxOccupancy: number;
  baseFare: number;
  ac: boolean;
  hotelId: number;
}

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [CommonModule, FormsModule, NavbarComponent, NgbCarouselModule, SafePipe],
  templateUrl: './admin.html',
  styleUrls: ['./admin.css']
})
export class AdminComponent implements OnInit {
  adminMenuItems = [
    { label: 'Show Users', action: () => this.getUsers() },
    { label: 'Search User', action: () => this.showDeleteUserForm() },
    { label: 'Show Hotels', action: () => this.viewHotels() },
    { label: 'Search Hotel', action: () => this.showSearchHotelForm() },
  ];

  users: User[] = [];
  showUsers = false;
  showDeleteUser = false;
  userIdToFetch: number | null = null;
  userToDelete: User | null = null;

  // Hotel-related properties
  showHotels = false;
  hotels: Hotel[] = [];
  rooms: Room[] = [];
  selectedHotel: Hotel | null = null;
  showSearchHotel = false;
  searchLocation = '';

  constructor(private http: HttpClient, private authService: AuthService, private router: Router) {}

  ngOnInit() {}

  getUsers() {
    this.http.get<User[]>('http://localhost:8080/api/users').subscribe((data) => {
      this.users = data;
      this.showUsers = true;
      this.showDeleteUser = false;
      this.userToDelete = null;
      this.showHotels = false;
      this.showSearchHotel = false;
    });
  }

  showDeleteUserForm() {
    this.showUsers = false;
    this.showDeleteUser = true;
    this.userToDelete = null;
    this.showHotels = false;
    this.showSearchHotel = false;
  }

  getUserToDelete() {
    if (this.userIdToFetch) {
      this.http.get<User>(`http://localhost:8080/api/users/${this.userIdToFetch}`).subscribe({
        next: (data) => {
          if (data) {
            this.userToDelete = data;
          } else {
            alert('User with the specified ID does not exist.');
            this.userToDelete = null;
          }
        },
        error: () => {
          // This will still catch other server errors, like 500 Internal Server Error
          alert('An error occurred while fetching the user.');
          this.userToDelete = null;
        }
      });
    }
  }

  deleteUserById(id: number) {
    if (confirm('Are you sure you want to delete this user?')) {
      this.http.delete(`http://localhost:8080/api/users/${id}`).subscribe(() => {
        alert('User deleted successfully!');
        // Remove the deleted user from the users array
        this.users = this.users.filter(user => user.id !== id);
      }, error => {
        alert('Failed to delete user.');
      });
    }
  }

  // Hotel logic
  viewHotels() {
    this.hotels = [];
    this.showSearchHotel = false;
    this.http.get<Hotel[]>('http://localhost:8080/api/hotels').subscribe((data) => {
      this.hotels = data;
      this.showHotels = true;
      this.showUsers = false;
      this.showDeleteUser = false;
      this.selectedHotel = null;
      this.rooms = [];
    });
  }

  deleteHotelById(id: number) {
    if (confirm('Are you sure you want to delete this hotel?')) {
      this.http.delete(`http://localhost:8080/api/hotels/${id}`).subscribe(() => {
        alert('Hotel deleted successfully!');
        this.hotels = this.hotels.filter(hotel => hotel.id !== id);
      }, error => {
        alert('Failed to delete hotel.');
      });
    }
  }

  showUpdateOwnerForm() {
    // Implement your update owner logic here
  }

  showDeleteOwnerForm() {
    // Implement your delete owner logic here
  }

  showSearchHotelForm() {
    this.showUsers = false;
    this.showDeleteUser = false;
    this.showHotels = false;
    this.showSearchHotel = true;
    this.hotels = [];
    this.searchLocation = '';
  }

  searchHotels() {
    this.hotels = [];
    this.showHotels = false;
    this.http.get<Hotel[]>(`http://localhost:8080/api/hotels/search?location=${this.searchLocation}`).subscribe((data) => {
      this.hotels = data;
      this.showSearchHotel = true;
    });
  }

  showDashboard() {
    this.showUsers = false;
    this.showDeleteUser = false;
    this.showHotels = false;
    this.showSearchHotel = false;
    this.userToDelete = null;
    this.hotels = [];
    this.rooms = [];
    this.selectedHotel = null;
    this.userIdToFetch = null;
    this.searchLocation = '';
  }
}