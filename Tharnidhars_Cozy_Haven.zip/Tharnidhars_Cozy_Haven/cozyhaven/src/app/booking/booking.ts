import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SafePipe } from '../safe.pipe';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth.service';

interface Hotel {
  id: number;
  name: string;
  location: string;
  description: string;
  amenities: string;
  image: string;
}

interface Room {
  id: number;
  roomSize: string;
  bedType: string;
  maxOccupancy: number;
  baseFare: number;
  ac: boolean;
  hotelId: number;
}

@Component({
  selector: 'app-booking',
  standalone: true,
  imports: [CommonModule, FormsModule, SafePipe],
  templateUrl: './booking.html',
  styleUrls: ['./booking.css']
})
export class BookingComponent implements OnInit, OnDestroy {
  hotel: Hotel | null = null;
  rooms: Room[] = [];
  hotelId: string | null = null;
  private subscriptions: Subscription[] = [];

  // Booking form state
  showBookingForm = false;
  selectedRoom: Room | null = null;
  bookingData = {
    userId: null as number | null,
    roomId: null as number | null,
    checkInDate: '',
    checkOutDate: '',
    numberOfAdults: 0,
    numberOfChildren: 0,
    numberOfRooms: 0,
    totalFare: 0,
    status: 'pending',
  };
  baseFare: number = 0;
  showPaymentModal = false;
  currentUser: any = null;
  minCheckInDate: string = new Date().toISOString().split('T')[0];
  get minCheckOutDate(): string {
    return this.bookingData.checkInDate ? this.bookingData.checkInDate : this.minCheckInDate;
  }

  // Review state
  reviews: any[] = [];
  newReview = {
    userId: 0,
    hotelId: 0,
    rating: 0,
    comment: ''
  };
  submittingReview = false;

  // Add a getter for booking form validity
  get isBookingFormValid(): boolean {
    return !!(
      this.bookingData.checkInDate &&
      this.bookingData.checkOutDate &&
      Number(this.bookingData.numberOfAdults) > 0 &&
      Number(this.bookingData.numberOfRooms) > 0
    );
  }

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {
    this.hotelId = this.route.snapshot.paramMap.get('hotelId');
    if (this.hotelId) {
      this.subscriptions.push(
        this.http.get<Hotel>(`http://localhost:8080/api/hotels/${this.hotelId}`).subscribe(hotel => {
          this.hotel = hotel;
          this.newReview.hotelId = hotel.id;
          this.fetchReviews();
        })
      );
      this.subscriptions.push(
        this.http.get<Room[]>(`http://localhost:8080/api/rooms/hotel/${this.hotelId}`).subscribe(rooms => {
          this.rooms = rooms;
        })
      );
    }
    // Autofill userId from AuthService
    const email = this.authService.getEmail();
    console.log('Fetched email from token:', email);
    if (email) {
      this.authService.getUsers().subscribe(users => {
        console.log('Fetched users:', users);
        const currentUser = users.find((user: any) => user.email === email);
        console.log('Matched currentUser:', currentUser);
        if (currentUser) {
          this.currentUser = currentUser;
          this.bookingData.userId = currentUser.id;
          this.newReview.userId = currentUser.id;
        }
      });
    }
  }

  ngOnDestroy() {
    this.subscriptions.forEach(sub => sub.unsubscribe());
  }

  goBack() {
    this.router.navigate(['/user']);
  }

  bookRoom(room: Room) {
    this.selectedRoom = room;
    this.bookingData.roomId = room.id;
    this.baseFare = room.baseFare;
    this.showBookingForm = true;
    this.showPaymentModal = false;
    // Reset form fields except userId and roomId
    this.bookingData.checkInDate = '';
    this.bookingData.checkOutDate = '';
    this.bookingData.numberOfAdults = 0;
    this.bookingData.numberOfChildren = 0;
    this.bookingData.numberOfRooms = 0;
    this.bookingData.totalFare = 0;
    this.bookingData.status = 'pending';
    // Set userId if available
    if (this.currentUser) {
      this.bookingData.userId = this.currentUser.id;
    }
  }

  calculateTotalFare() {
    const { numberOfAdults, numberOfChildren, numberOfRooms, checkInDate, checkOutDate } = this.bookingData;
    const adults = Number(numberOfAdults) || 0;
    const children = Number(numberOfChildren) || 0;
    const rooms = Number(numberOfRooms) || 0;
    const baseFare = this.baseFare;
    let days = 0;
    if (checkInDate && checkOutDate) {
      const inDate = new Date(checkInDate);
      const outDate = new Date(checkOutDate);
      // Calculate days difference (exclusive of checkout date)
      days = Math.max(1, Math.ceil((outDate.getTime() - inDate.getTime()) / (1000 * 60 * 60 * 24)));
    }
    const perDayFare = adults * baseFare + children * (baseFare / 2);
    this.bookingData.totalFare = days * rooms * perDayFare;
  }

  submitBooking() {
    this.showBookingForm = false;
    this.showPaymentModal = true;
  }

  proceedToPay() {
    const bookingPayload = { ...this.bookingData };
    this.http.post('http://localhost:8080/api/bookings', bookingPayload).subscribe({
      next: () => {
        alert('Payment successful! Booking confirmed.');
        this.showPaymentModal = false;
      },
      error: () => {
        alert('Payment failed. Please try again.');
      }
    });
  }

  fetchReviews() {
    if (!this.hotelId) return;
    this.http.get<any[]>(`http://localhost:8080/api/reviews/hotel/${this.hotelId}`).subscribe(data => {
      this.reviews = data;
    });
  }

  setReviewRating(rating: number) {
    this.newReview.rating = rating;
  }

  submitReview() {
    if (!this.newReview.rating || !this.newReview.comment.trim()) return;
    this.submittingReview = true;
    this.http.post('http://localhost:8080/api/reviews', this.newReview).subscribe(() => {
      this.newReview.rating = 0;
      this.newReview.comment = '';
      this.submittingReview = false;
      this.fetchReviews();
    }, () => {
      this.submittingReview = false;
    });
  }
} 