import { Component, OnInit, OnDestroy } from '@angular/core';
import { NavbarComponent } from '../navbar/navbar';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';
import { Router } from '@angular/router';

interface Hotel {
  id: number;
  name: string;
  location: string;
  description: string;
  amenities: string;
  image: string;
}

interface Room {
  id: number;
  roomSize: string;
  bedType: string;
  maxOccupancy: number;
  baseFare: number;
  ac: boolean;
  hotelId: number;
}

interface Booking {
  userId: number | null;
  roomId: number;
  checkInDate: string;
  checkOutDate: string;
  numberOfAdults: number;
  numberOfChildren: number;
  numberOfRooms: number;
  totalFare: number;
}

import { SafePipe } from '../safe.pipe';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [ NavbarComponent, CommonModule, FormsModule, SafePipe ],
  templateUrl: './user.html',
  styleUrls: ['./user.css']
})
export class UserComponent implements OnInit, OnDestroy {
  userMenuItems = [
    { label: 'View Hotels', action: () => this.viewHotels() },
    { label: 'Find Hotel', action: () => this.showBook() },
    { label: 'My Profile', path: '/user/profile' }
  ];

  hotels: Hotel[] = [];
  rooms: Room[] = [];
  showHotels = false;
  showSearch = false;
  searchLocation = '';
  selectedHotel: Hotel | null = null;
  selectedRoomForBooking: Room | null = null;
  bookingData: Booking = {
    userId: null, // Will be entered by the user
    roomId: 0,
    checkInDate: '',
    checkOutDate: '',
    numberOfAdults: 1,
    numberOfChildren: 0,
    numberOfRooms: 1,
    totalFare: 0,
  };
  currentUser: any;

  carouselImages = [
    'assets/hotel1.jpg',
    'assets/hotel2.jpeg',
    'assets/hotel3.png'
  ];
  currentSlide = 0;
  private carouselInterval: any;

  testimonials = [
    {
      name: 'Priya S.',
      text: 'The rooms were spotless and the staff was incredibly friendly. I loved the breakfast buffet!'
    },
    {
      name: 'Rahul M.',
      text: 'Booking was seamless and the sea view from my room was breathtaking. Will visit again!'
    },
    {
      name: 'Aditi K.',
      text: 'The amenities were top-notch and the pool was so relaxing. Highly recommend Cozy Haven!'
    },
    {
      name: 'Vikram P.',
      text: 'Fast check-in, comfy beds, and great location near the city center. Five stars!'
    }
  ];
  testimonialIndex = 0;
  private testimonialInterval: any;

  constructor(private http: HttpClient, private authService: AuthService, private router: Router) {}

  ngOnInit() {
    const email = this.authService.getEmail();
    if (email) {
      this.authService.getUsers().subscribe(users => {
        const currentUser = users.find(user => user.email === email);
        if (currentUser) {
          this.currentUser = currentUser;
        }
      });
    }
    this.startCarousel();
    this.startTestimonialAutoAdvance();
  }

  ngOnDestroy() {
    if (this.carouselInterval) {
      clearInterval(this.carouselInterval);
    }
    if (this.testimonialInterval) {
      clearInterval(this.testimonialInterval);
    }
  }

  startCarousel() {
    this.carouselInterval = setInterval(() => {
      this.nextSlide();
    }, 2000);
  }

  nextSlide() {
    this.currentSlide = (this.currentSlide + 1) % this.carouselImages.length;
  }

  prevSlide() {
    this.currentSlide = (this.currentSlide - 1 + this.carouselImages.length) % this.carouselImages.length;
  }

  prevSlideIndex() {
    return (this.currentSlide - 1 + this.carouselImages.length) % this.carouselImages.length;
  }

  nextSlideIndex() {
    return (this.currentSlide + 1) % this.carouselImages.length;
  }

  startTestimonialAutoAdvance() {
    this.testimonialInterval = setInterval(() => {
      this.nextTestimonial();
    }, 4000);
  }

  nextTestimonial() {
    this.testimonialIndex = (this.testimonialIndex + 1) % this.testimonials.length;
  }

  prevTestimonial() {
    this.testimonialIndex = (this.testimonialIndex - 1 + this.testimonials.length) % this.testimonials.length;
  }

  viewHotels() {
    this.http.get<Hotel[]>('http://localhost:8080/api/hotels').subscribe((data) => {
      this.hotels = data;
      this.showHotels = true;
      this.showSearch = false;
      this.selectedHotel = null;
      this.rooms = [];
    });
  }

  showBook() {
    this.showHotels = false;
    this.showSearch = true;
    this.hotels = [];
    this.selectedHotel = null;
    this.rooms = [];
  }

  searchHotels() {
    if (!this.searchLocation.trim()) {
      this.hotels = [];
      this.showHotels = false;
      return;
    }
    // Try searching by both name and location
    this.http.get<Hotel[]>(`http://localhost:8080/api/hotels/search?location=${this.searchLocation}`)
      .subscribe((locationData) => {
        // Try searching by name as well
        this.http.get<Hotel[]>(`http://localhost:8080/api/hotels/searchByName?name=${this.searchLocation}`)
          .subscribe((nameData) => {
            // Merge and deduplicate results
            const allHotels = [...locationData, ...nameData].filter((hotel, index, self) =>
              index === self.findIndex(h => h.id === hotel.id)
            );
            this.hotels = allHotels;
            this.showHotels = true;
            this.selectedHotel = null;
            this.rooms = [];
          }, () => {
            // If name search fails, just use location results
            this.hotels = locationData;
            this.showHotels = true;
            this.selectedHotel = null;
            this.rooms = [];
          });
      });
  }

  viewRooms(hotel: Hotel) {
    this.selectedHotel = hotel;
    this.http.get<Room[]>(`http://localhost:8080/api/rooms/hotel/${hotel.id}`).subscribe((data) => {
      this.rooms = data;
    });
  }

  showBookingForm(room: Room) {
    this.selectedRoomForBooking = room;
    this.bookingData.roomId = room.id;
    if (this.currentUser) {
      this.bookingData.userId = this.currentUser.id;
    }
  }

  calculateTotalFare() {
    if (this.selectedRoomForBooking) {
      const adults = this.bookingData.numberOfAdults || 0;
      const children = this.bookingData.numberOfChildren || 0;
      const rooms = this.bookingData.numberOfRooms || 0;
      this.bookingData.totalFare = (adults + children) * this.selectedRoomForBooking.baseFare * rooms;
    }
  }

  submitBooking() {
    this.calculateTotalFare();
    this.http.post('http://localhost:8080/api/bookings', this.bookingData).subscribe(() => {
      alert('Booking successful!');
      this.selectedRoomForBooking = null;
    });
  }

  showWelcome() {
    this.showHotels = false;
    this.showSearch = false;
    this.hotels = [];
    this.selectedHotel = null;
    this.selectedRoomForBooking = null;
    this.rooms = [];
    this.searchLocation = '';
  }

  goToBookingPage(hotel: Hotel) {
    this.router.navigate(['/user/booking', hotel.id]);
  }
}
