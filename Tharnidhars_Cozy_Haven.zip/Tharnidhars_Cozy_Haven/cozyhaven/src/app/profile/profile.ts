import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { AuthService } from '../auth.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
// Make sure FontAwesome is included in your index.html or globally for icons to work

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [CommonModule, FormsModule, HttpClientModule],
  templateUrl: './profile.html',
  styleUrls: ['./profile.css']
})
export class ProfileComponent implements OnInit {
  user: any = null;
  bookings: any[] = [];
  showCancelCard: boolean = false;
  bookingToCancel: any = null;
  message: string = '';

  constructor(private http: HttpClient, private authService: AuthService, private router: Router) {}

  ngOnInit() {
    const email = this.authService.getEmail();
    if (email) {
      this.authService.getUsers().subscribe(users => {
        const currentUser = users.find((u: any) => u.email === email);
        if (currentUser) {
          this.user = currentUser;
          this.fetchBookings(currentUser.id);
        }
      });
    }
  }

  fetchBookings(userId: number) {
    this.http.get<any[]>(`http://localhost:8080/api/bookings/user/${userId}`).subscribe(data => {
      this.bookings = data;
    });
  }

  back() {
    this.router.navigate(['/user']);
  }

  showCancelBooking(booking: any) {
    this.bookingToCancel = booking;
    this.showCancelCard = true;
  }

  proceedCancelBooking() {
    if (!this.bookingToCancel) return;
    this.http.delete(`http://localhost:8080/api/bookings/${this.bookingToCancel.id}`).subscribe(() => {
      this.message = 'Refund will be processed.';
      this.showCancelCard = false;
      this.fetchBookings(this.user.id);
    });
  }

  closeCancelCard() {
    this.showCancelCard = false;
    this.bookingToCancel = null;
  }
} 